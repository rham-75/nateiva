// Sélectionnez les éléments nécessaires
var signin_eye_click = document.querySelector(".fa-eye-slash");
var signin_type = document.querySelector(".signin_pass");

var signup_eye_click = document.querySelector(".fa-eye");
var signup_type = document.querySelector(".signup_pass");

// Ajoutez un écouteur d'événement au clic sur l'icône d'œil pour le formulaire de connexion

    signin_eye_click.addEventListener("click", function () {
        if (signin_type.type === "password") {
            signin_type.type = "text";
            signin_eye_click.classList.remove("fa-eye-slash");
            signin_eye_click.classList.add("fa-eye");
        } else {
            signin_type.type = "password";
            signin_eye_click.classList.add("fa-eye-slash");
            signin_eye_click.classList.remove("fa-eye");
        }
    });


// Ajoutez un écouteur d'événement au clic sur l'icône d'œil pour le formulaire d'inscription

    signup_eye_click.addEventListener("click", function () {
        if (signup_type.type === "password") {
            signup_type.type = "text";
            signup_eye_click.classList.remove("fa-eye");
            signup_eye_click.classList.add("fa-eye-slash");
        } else {
            signup_type.type = "password";
            signup_eye_click.classList.add("fa-eye");
            signup_eye_click.classList.remove("fa-eye-slash");
        }
    });

